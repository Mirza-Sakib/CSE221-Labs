
//@author 18101142
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

public class Task1 {

    static String[] city;
    static int g[][];
    static int key[];
    static int p[];

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        File f = new File("C:\\Users\\Admin\\Desktop\\GraphD.txt");
        BufferedReader b = new BufferedReader(new FileReader(f));
        String s = b.readLine();
        int n = Integer.parseInt(s);
        g = new int[n][n];
        city = new String[n];
        s = b.readLine();
        StringTokenizer stName = new StringTokenizer(s, " ");
        for (int i = 0; i < n; i++) {
            city[i] = stName.nextToken();
        }
        //string to int
        while ((s = b.readLine()) != null) {
            for (int i = 0; i < g.length; i++) {
                StringTokenizer stG = new StringTokenizer(s, " ");
                for (int j = 0; j < g.length; j++) {
                    g[i][j] = Integer.parseInt(stG.nextToken());
                }
            }
        }
        MST(g, 0);
        int l = 1;
        for (int k = 1; k < n; k++) {
            System.out.print("(" + city[p[l]] + "---" + city[k] + ") ");
            l++;
        }
    }

    public static void MST(int g[][], int r) {
        key = new int[g.length];
        p = new int[g.length];
        for (int u = 0; u < g.length; u++) {
            key[u] = Integer.MAX_VALUE;
            p[u] = -1;  
        }
        key[r] = 0;
        p[r]=r;
        PriorityQueue<Integer> q = new PriorityQueue<>();

//        for (int x = 0; x < key.length; x++) {
//            q.add(key[x]);
//        }
        int u;
        while (!q.isEmpty()) {
            u = q.poll();
            for (int j = 0; j < g.length; j++) {
                if ((q.contains(j)) && g[u][j] < key[j]) {
                    p[j] = u;
                    key[j] = g[u][j];
                    q.add(key[j]);
                }
            }
        }
    }
}
