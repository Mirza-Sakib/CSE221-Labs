/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task03;

/**
 *
 * @author 17101039
 */
import java.util.*;
public class MyArray{
  public static void printarr(int [] arr){
    for(int i=0;i<arr.length;i++){
      System.out.print(arr[i]+",");
    }
    System.out.println();
  }
   public static void mergesort(int [] arr,int i,int j){
    int mid=0;
    if(j>i){
     mid=(i+j)/2;
     mergesort(arr,i,mid);
     mergesort(arr,mid+1,j);
     merge(arr,i,mid,j);
    }
   }
    public static void merge(int []arr,int i,int mid,int j){
      int [] temp=new int [arr.length];
      int l=i;
      int r=j;
      int m=mid+1;
      int k=l;
      while(l <= mid && m <= r) {
      if(arr[l] <= arr[m]) {
        temp[k++] = arr[l++];
      }
      else {
        temp[k++] = arr[m++];
      }
    }
      while(l <= mid)
      temp[k++] = arr[l++];

    while(m <= r) {
      temp[k++] = arr[m++];
    }

    for(int i1 = i; i1 <= j; i1++) {
      arr[i1] = temp[i1];
    }
    }
      
}
