/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task03;

/**
 *
 * @author 17101039
 */
import java.util.*;
public class SortTest{
  public static void main(String[]args){
    int arr[]={3,5,10,23,25,8,7,9,50,47};
    MyArray a=new MyArray();
    int [] copy=new int [arr.length];
    for(int i=0;i<arr.length;i++){
      copy[i]=arr[i];
    }
     long c=System.currentTimeMillis();
     a.mergesort(copy,0,copy.length-1);
    long b=System.currentTimeMillis();
    System.out.println("Unsorted: ");
    a.printarr(arr);
    System.out.println("Sorted: ");
    a.printarr(copy);
    System.out.println("Runtime: ");
    System.out.println(b-c);

  }
}
