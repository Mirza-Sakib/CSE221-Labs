package Task02;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 17101039
 */
import java.util.*;
public class MyArray{
  public static void printarr(int [] arr){
    for(int i=0;i<arr.length;i++){
      System.out.print(arr[i]+",");
    }
    System.out.println();
  }
  public static void insertionSort(int [] arr){
    int n=arr.length;
    for(int j=1;j<n;j++){
      int key= arr[j];
      int i=j-1;
      while(i>-1 && arr[i]>key){
        arr[i+1]=arr[i];
      i--;
      }
      arr[i+1]=key;
    }
  }
}
