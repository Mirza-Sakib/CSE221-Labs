package Task01;
public class MyArray {
    static int[] insertionSort(int[] arr) {
        int[] temp = copyArray(arr);
        
        for(int i = 1; i < temp.length; i++) {
            int key = temp[i];
            
            int j = i-1;
            while(j >= 0 && key < temp[j]) {
                temp[j+1] = temp[j];
                j--;
            }
            temp[j+1] = key;
        }
        
        return temp;
    }
    static int[] mergeSort(int[] arr) {
        if(arr.length == 1) {
            return arr;
        }
        else {
            int[] a1 = copyArray(arr, 0, arr.length/2-1);
            int[] a2 = copyArray(arr, arr.length/2, arr.length-1);
            int[] arr1 = mergeSort(a1);
            int[] arr2 = mergeSort(a2);
            return merge(arr1,arr2);
        }
    }
    static int[] merge(int[] a1, int[] a2) {
        int[] a = new int[a1.length+a2.length];
        int index1, index2;
        index1 = index2 = 0;
        int i = 0;
        while (index1 < a1.length || index2 < a2.length) {
            if(index1 == a1.length) {
                a[i] = a2[index2];
                index2++;
            }
            else if(index2 == a2.length) {
                a[i] = a1[index1];
                index1++;
            }
            else if(a1[index1] < a2[index2]) {
                a[i] = a1[index1];
                index1++;
            }
            else {
                a[i] = a2[index2];
                index2++;
            }
            i++;
        }
        return a;
    }
    
    static int[] quickSort(int[] arr,int begin,int end) {
        int[] temp = copyArray(arr);
        if(begin<end){
            int partitionIndex = partition(temp,begin,end);
            quickSort(temp,begin,partitionIndex-1);
            quickSort(temp,partitionIndex+1,end);
        }
        
       return temp;
    }
    static int partition(int[] tmp,int begin,int end){
        int pivot = tmp[end];
        int i = begin-1;
        for(int j = begin;j<end;j++){
            if(tmp[j] <= pivot){
                i++;
                int Swap = tmp[i];
                tmp[i] = tmp[j];
                tmp[j] = Swap;
            }
        }
        int Swap = tmp[i+1];
                tmp[i+1] = tmp[end];
                tmp[end] = Swap;
                
                return i+1;
    }
    static int[] copyArray(int[] arr) {
        int[] copiedArray = new int[arr.length];
        for(int i = 0; i < arr.length; i++) {
            copiedArray[i] = arr[i];
        }
        return copiedArray;
    }
    static int[] copyArray(int[] arr, int start, int end) {
        int[] copiedArray = new int[end-start+1];
        int j = 0;
        for(int i = start; i <= end; i++, j++) {
            copiedArray[j] = arr[i];
        }
        return copiedArray;
    }
    static void printArray(int[] arr) {
        for(int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]+" ");
        }
        System.out.println();
    }
}
