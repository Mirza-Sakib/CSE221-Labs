package Task01;
public class SortTest {
    public static void main(String[] args) {
        int[] arr = {3, 5, 10, 23, 25, 8, 7, 9, 50, 47};
        
        long t1 = System.currentTimeMillis();
        int[] insSortedArray = MyArray.insertionSort(arr);
        long t2 = System.currentTimeMillis();
        
        MyArray.printArray(arr);
        MyArray.printArray(insSortedArray);
        
        long t = t2-t1;
        System.out.println("Time taken for insertion sort: "+t);
        
        t1 = System.currentTimeMillis();
        int[] mergeSortedArray = MyArray.mergeSort(arr);
        t2 = System.currentTimeMillis();
        
        MyArray.printArray(arr);
        MyArray.printArray(mergeSortedArray);
        
        t = t2-t1;
        System.out.println("Time taken for merge sort: "+t);
       
        t1 = System.currentTimeMillis();
        //int bgn = 0;int end =arr.length-1;
        int[] quickSortedArray = MyArray.quickSort(arr,0,arr.length-1);
        t2 = System.currentTimeMillis();
        
        MyArray.printArray(arr);
        MyArray.printArray(quickSortedArray);
        
        t=t2-t1;
        System.out.println("Time taken for quick sort: "+t);
    }
}
