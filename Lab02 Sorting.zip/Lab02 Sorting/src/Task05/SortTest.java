/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task05;

/**
 *
 * @author 17101039
 */
import java.util.Random;
public class SortTest extends MyArray{

    
       public static void main(String args[]) 
    {
       
        Random random = new Random();
 
        for (int i = 0; i < N; i++)
            sequence[i] = Math.abs(random.nextInt(100));
 
        System.out.println("Unsorted: ");
        
        printSequence(sequence);
        System.out.println();
        System.out.println("Sorted: ");
         long c=System.currentTimeMillis();
        QuickSort(0, N - 1);
        long b=System.currentTimeMillis();
        printSequence(sequence);
        System.out.println();
            System.out.println("Runtime: ");
    System.out.println(b-c);
    }
}

