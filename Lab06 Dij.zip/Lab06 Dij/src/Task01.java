
import java.util.*;
import java.io.*;

public class Task01 {

    static int distance[];
    static int parent[];
    static boolean check[];
    static ArrayList<String> node = new ArrayList<String>();
    static String[] nx;

    public static void main(String[] args) throws Exception {

        File f = new File("‪C:\\Users\\Admin\\Desktop\\graph.txt");
        BufferedReader b = new BufferedReader(new FileReader(f));
        String s = b.readLine();

        int n = Integer.parseInt(s);
        int[][] g = new int[n][n];

        s = b.readLine();
        StringTokenizer st = new StringTokenizer(s, " ");

        while (st.hasMoreTokens()) {
            node.add(st.nextToken());
        }

        nx = new String[node.size()];
        parent = new int[n];
        distance = new int[n];
        check = new boolean[n];

        for (int i = 0; i < nx.length; i++) {
            nx[i] = node.get(i);
        }
        System.out.println("All the nodes are: "+node.toString());

        while ((s = b.readLine()) != null) {
            st = new StringTokenizer(s, " ");
            int x = node.indexOf(st.nextToken());
            int y = node.indexOf(st.nextToken());
            g[x][y] = Integer.parseInt(st.nextToken());

        }

        Dijkstra(g, 0);
        System.out.print("\nPath: " );
        printPath(0, n - 1);
    }

    public static void Dijkstra(int[][] matrix, int s) {

        for (int v = 0; v < matrix.length; v++) {
            distance[v] = Integer.MAX_VALUE;
            parent[v] = -1;
        }
        distance[s] = 0;

        for (int i = 0; i < matrix.length; i++) {
            int u = findMin();
            check[u] = true;
            for (int v = 1; v < matrix.length; v++) {
                if (distance[v] > distance[u] + matrix[u][v] && matrix[u][v] != 0) {
                    distance[v] = distance[u] + matrix[u][v];
                    parent[v] = u;
                }
            }
        }
    }

    public static int findMin() {
        int min =Integer.MAX_VALUE, k = 0;

        for (int i = 1; i < distance.length; i++) {
            if (distance[i] < min && check[i] == false) {
                min = distance[i];
                k = i;
            }
        }
        return k;
    }

    public static void printPath(int source, int destination) {
        if (destination > source) {
            printPath(source, parent[destination]);
        }
        if (destination != nx.length - 1) {
            System.out.print(nx[destination] + "-->");
        } else {
            System.out.println(nx[destination]);
        }
    }
}