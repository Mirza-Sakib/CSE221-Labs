package Task2;

//@author 18101142
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class Task2 {

    static String color[];
    static int p[];
    static int dis[];
    static int fin[];
    static int topo[];
    static int time = 0;
    static int z = 0;
    static Queue q = new LinkedList();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // TODO code application logic here
        //Graph
        File f = new File("‪C:\\Users\\Admin\\Desktop\\graph.txt");
        BufferedReader b = new BufferedReader(new FileReader(f));
        String s = b.readLine();
        int n = Integer.parseInt(s);
        int[][] g = new int[n][n];
        //string to int
        while ((s = b.readLine()) != null) {
            StringTokenizer st = new StringTokenizer(s, " ");
            int t1 = Integer.parseInt(st.nextToken());
            int t2 = Integer.parseInt(st.nextToken());
            g[t1][t2] = 1;
        }
        LinkedList[] a1 = new LinkedList[n];
        for (int i = 0; i < a1.length; i++) {
            a1[i] = new LinkedList();
        }
        for (int i = 0; i < g.length; i++) {
            for (int j = 0; j < g.length; j++) {
                a1[i].add(g[i][j]);
            }
        }
        color = new String[n];
        p = new int[n];
        dis = new int[n];
        fin = new int[n];
        topo = new int[n];
        for (int i = 0; i < n; i++) {
            color[i] = "White";
            p[i] = 999999999;
        }
        for (int i = 1; i < n; i++) {
            if (color[i] == "White") {
                dfsVisit(g, i);
            }
        }
        Arrays.sort(fin);
        System.out.print("\nTask2");
        System.out.println("\nAftter topo sort:");
        for (int x = fin.length - 1; x > 0; x--) {
            if (x > 1) {
                System.out.print(topo[x] + "-->");
            } else {
                System.out.print(topo[x]);
            }
        }
        System.out.print("\nFinished Time: ");
        for (int x = fin.length - 1; x > 0; x--) {
            if (x > 1) {
                System.out.print(fin[x] + ", ");
            } else {
                System.out.print(fin[x] + ".");
            }
        }
    }

    public static void dfsVisit(int[][] g, int u) {

        color[u] = "Gray";
        time++;
        dis[u] = time;
        for (int i = 0; i < g.length; i++) {
            if (g[u][i] == 1 && color[i] == "White") {
                p[i] = u;

                dfsVisit(g, i);
            }
        }
        color[u] = "Black";
        fin[u] = ++time;
        topo[++z] = u;
        q.add(u);
    }
}
