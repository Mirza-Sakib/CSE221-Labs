/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task3;

/**
 *
 * @author SHOVON
 */
import java.io.*;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class Task3 {

    static String color[];
    static int dt[];
    static int ft[];
    static int parent[];
    static int time;
    static Queue q = new LinkedList();

    public static void main(String[] args) throws Exception {
        File file = new File("‪C:\\Users\\Admin\\Desktop\\maze.txt");

        BufferedReader br = new BufferedReader(new FileReader(file));
        String s = br.readLine();
        int n = Integer.parseInt(s);
        int g[][] = new int[n][n];

        while ((s = br.readLine()) != null) {
            StringTokenizer st = new StringTokenizer(s, " ");
            int t1 = Integer.parseInt(st.nextToken());
            int t2 = Integer.parseInt(st.nextToken());
            g[t1][t2] = 1;
        }
        int c = 0;
        System.out.println("Directed Graph\nAdjacenty List\n  0 1 2 3 4 5 6 7 8 9 10 11");
        for (int i = 0; i < g.length; i++) {
            System.out.print(c++ + " ");
            for (int j = 0; j < g.length; j++) {
                System.out.print(g[i][j] + " ");
            }
            System.out.println();
        }
        color = new String[n];
        dt = new int[n];
        ft = new int[n];
        parent = new int[n];
        DFS(g);
    }

    public static void DFS(int[][] matrix) {
        for (int u = 1; u < matrix.length; u++) {
            color[u] = "white";
            parent[u] = 0;
        }
        time = 0;
        for (int u = 1; u < matrix.length; u++) {
            if (color[u] == "white") {
                System.out.println("\nDiscoverd Nodes:");
                DFS_Visit(matrix, u);
                System.out.println("\nProcessed Nodes:" + q);
            }
        }
    }

    public static void DFS_Visit(int[][] matrix, int u) {
        color[u] = "gray";
        System.out.print(u + " ");
        time = time + 1;
        dt[u] = time;
        for (int v = 1; v < matrix.length; v++) {
            if (color[v] == "white" && matrix[u][v] != 0) {
                parent[v] = u;
                DFS_Visit(matrix, v);
            }
        }
        color[u] = "black";
        ft[u] = time++;
        if (u != 9) {
            q.add(u);
        }
    }
}
