package Task1;

//@author 18101142
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class Task1 {

    static String color[];
    static int p[];
    static int dis[];
    static int fin[];
    static int topo[];
    static int time = 0;
    static int z = 0;
    static Queue q = new LinkedList();

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        //Graph
        File f = new File("‪C:\\Users\\Admin\\Desktop\\graph.txt");
        BufferedReader b = new BufferedReader(new FileReader(f));
        String s = b.readLine();
        int n = Integer.parseInt(s);
        int[][] g = new int[n][n];
        //string to int
        while ((s = b.readLine()) != null) {
            StringTokenizer st = new StringTokenizer(s, " ");
            int t1 = Integer.parseInt(st.nextToken());
            int t2 = Integer.parseInt(st.nextToken());
            g[t1][t2] = 1;
        }
        LinkedList[] a1 = new LinkedList[n];
        for (int i = 0; i < a1.length; i++) {
            a1[i] = new LinkedList();
        }
        for (int i = 0; i < g.length; i++) {
            for (int j = 0; j < g.length; j++) {
                a1[i].add(g[i][j]);
            }
        }
        int c = 0;
        System.out.println("Adjacency Matrix :-\n  0 1 2 3 4 5 6");
        for (int i = 0; i < g.length; i++) {
            System.out.print(c++ + " ");
            for (int j = 0; j < g.length; j++) {
                System.out.print(g[i][j] + " ");
            }
            System.out.println();
        }
        color = new String[n];
        p = new int[n];
        dis = new int[n];
        fin = new int[n];
        topo = new int[n];
        for (int i = 0; i < n; i++) {
            color[i] = "White";
            p[i] = 999999999;
        }
        System.out.println("========================");
        System.out.print("Discovered Nodes: ");
        for (int i = 1; i < n; i++) {
            if (color[i] == "White") {
                dfsVisit(g, i);
            }
        }
        System.out.println("\nProcessed Nodes: " + q);
        Arrays.sort(fin);
        
    }

    public static void dfsVisit(int[][] g, int u) {

        color[u] = "Gray";
        System.out.print(u + " ");
        time++;
        dis[u] = time;
        for (int i = 0; i < g.length; i++) {
            if (g[u][i] == 1 && color[i] == "White") {
                p[i] = u;

                dfsVisit(g, i);
            }
        }
        color[u] = "Black";
        fin[u] = ++time;
        topo[++z] = u;
        q.add(u);
    }
}
